// ignore_for_file: unnecessary_brace_in_string_interps

import 'package:dio/dio.dart';
import 'package:random_weather/model/constant.dart';
import 'package:random_weather/model/prayer_time.dart';
import 'package:random_weather/model/weather.dart';

import 'connection_helper.dart';

class DataFetcher {
  final ConnectionHelper _connectionHelper = ConnectionHelper();

  Future<Weather?> fetchWeather({
    required double lat,
    required double lon,
  }) async {
    Weather? weather;
    // Map<String, dynamic> query = {
    //   "lat": lat,
    //   "lon": lon,
    //   "units": "metric",
    //   "appid": Keys.openWeatherMap,
    // };
    Response<dynamic>? response = await _connectionHelper.getData(
      "${APIs.weatherAPI}?lat=${lat}&lon=${lon}&units=metric&appid=${Keys.openWeatherMap}",
    );
    if (response != null) {
      if (response.statusCode == 200) {
        var data = response.data;
        weather = Weather(
          city: data["name"],
          country: data["sys"]["country"],
          status: data["weather"][0]["description"],
          weather: data["main"]["temp"],
          sunrise: data["sys"]["sunrise"],
          sunset: data["sys"]["sunset"],
          condition: data["weather"][0]["id"],
        );
      }
    }
    return weather;
  }

  Future<PrayerTime?> fetchPrayerTime({
    required double lat,
    required double lon,
  }) async {
    PrayerTime? prayerTime;
    Response<dynamic>? response = await _connectionHelper.getData(
        "${APIs.prayerAPI}?latitude=${lat}&longitude=${lon}&timezone=Asia%2FDhaka");
    if (response != null) {
      if (response.statusCode == 200) {
        var data = response.data["results"];
        prayerTime = PrayerTime(
          fajr: data["Fajr"],
          dhuhr: data["Dhuhr"],
          asr: data["Asr"],
          maghrib: data["Maghrib"],
          isha: data["Isha"],
        );
      }
    }
    return prayerTime;
  }
}

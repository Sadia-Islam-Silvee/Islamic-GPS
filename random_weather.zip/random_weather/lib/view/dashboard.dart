import 'package:feather_icons/feather_icons.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:random_weather/controller/data_fetcher.dart';
import 'package:random_weather/model/prayer_time.dart';
import 'package:random_weather/model/weather.dart';
import 'package:weather_icons/weather_icons.dart';

class Dashboard extends StatefulWidget {
  static const String id = "dashboard_screen";
  const Dashboard({Key? key}) : super(key: key);

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  final DataFetcher _dataFetcher = DataFetcher();
  Position? _currentLocation;
  Weather? _weather;
  PrayerTime? _prayerTime;

  @override
  void initState() {
    super.initState();
    _getCurrentWeatherAndPrayer();
  }

  _getCurrentWeatherAndPrayer() async {
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }
    await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.lowest,
      forceAndroidLocationManager: true,
    ).then((Position position) {
      setState(() {
        _currentLocation = position;
      });
    }).catchError((e) {
      print(e);
    });

    if (_currentLocation != null) {
      Weather? w = await _dataFetcher.fetchWeather(
        lat: _currentLocation!.latitude,
        lon: _currentLocation!.longitude,
      );
      if (w != null) {
        setState(() {
          _weather = w;
        });
      }
    }

    if (_currentLocation != null) {
      PrayerTime? p = await _dataFetcher.fetchPrayerTime(
        lat: _currentLocation!.latitude,
        lon: _currentLocation!.longitude,
      );
      if (p != null) {
        setState(() {
          _prayerTime = p;
        });
      }
    }
  }

  String calculateTime(int unixTime) {
    var date = DateTime.fromMillisecondsSinceEpoch(unixTime * 1000);
    var format = DateFormat.jm();
    var time = format.format(date);
    return time;
  }

  IconData getWeatherIcon(int condition) {
    if (condition < 300) {
      return WeatherIcons.thunderstorm;
    } else if (condition < 400) {
      return WeatherIcons.showers;
    } else if (condition < 600) {
      return WeatherIcons.rain;
    } else if (condition < 700) {
      return WeatherIcons.snow;
    } else if (condition < 800) {
      return WeatherIcons.smoke;
    } else if (condition == 800) {
      return WeatherIcons.day_sunny;
    } else if (condition <= 804) {
      return WeatherIcons.cloud;
    } else {
      return WeatherIcons.thermometer_internal;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.amber.shade200,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: _weather == null
              ? const Center(child: CircularProgressIndicator())
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                          width: MediaQuery.of(context).size.width * 0.6,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "${_weather!.city},",
                                softWrap: true,
                                style: TextStyle(
                                  fontSize: 40,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                _weather!.country,
                                softWrap: true,
                                style: TextStyle(
                                  fontSize: 40,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(vertical: 16.0),
                                child: Text(
                                  _weather!.status.toUpperCase(),
                                  style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    fontSize: 20,
                                  ),
                                ),
                              ),
                              Text(
                                "${_weather!.weather}°C",
                                style: TextStyle(
                                  fontSize: 40,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 16.0),
                                child: Text(
                                  "Sunrise ${calculateTime(_weather!.sunrise)}  Sunset ${calculateTime(_weather!.sunset)}",
                                  style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Icon(
                          getWeatherIcon(_weather!.condition),
                          size: 116,
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 50,
                    ),
                    _prayerTime == null
                        ? Center(child: CircularProgressIndicator())
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "Prayer Times",
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 32,
                                ),
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: const [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 20.0),
                                    child: Text(
                                      "Waqt",
                                      style: TextStyle(
                                        fontWeight: FontWeight.w500,
                                        fontSize: 20,
                                      ),
                                    ),
                                  ),
                                  Text(
                                    "Starts at",
                                    style: TextStyle(
                                      fontWeight: FontWeight.w500,
                                      fontSize: 20,
                                    ),
                                  ),
                                ],
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 8.0),
                                child: WaqtRow(
                                  waqt: "Fazr",
                                  startsAt: _prayerTime!.fajr.split("%").join(),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 8.0),
                                child: WaqtRow(
                                  waqt: "Dhuhr",
                                  startsAt:
                                      _prayerTime!.dhuhr.split("%").join(),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 8.0),
                                child: WaqtRow(
                                  waqt: "Asr",
                                  startsAt: _prayerTime!.asr.split("%").join(),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 8.0),
                                child: WaqtRow(
                                  waqt: "Maghrib",
                                  startsAt:
                                      _prayerTime!.maghrib.split("%").join(),
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 8.0),
                                child: WaqtRow(
                                  waqt: "Isha",
                                  startsAt: _prayerTime!.isha.split("%").join(),
                                ),
                              ),
                            ],
                          )
                  ],
                ),
        ),
      ),
    );
  }
}

class WaqtRow extends StatelessWidget {
  final String waqt;
  final String startsAt;

  const WaqtRow({
    Key? key,
    required this.waqt,
    required this.startsAt,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(waqt),
        Text(startsAt),
      ],
    );
  }
}

class Weather {
  String city;
  String country;
  String status;
  double weather;
  int sunrise;
  int sunset;
  int condition;

  Weather({
    required this.city,
    required this.country,
    required this.status,
    required this.weather,
    required this.sunrise,
    required this.sunset,
    required this.condition,
  });
}

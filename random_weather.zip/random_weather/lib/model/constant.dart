class Keys {
  static const String openWeatherMap = 'd82ec44e2b0440e2f4e63f1bcc5e36df';
}

class APIs {
  static const String weatherAPI =
      "https://api.openweathermap.org/data/2.5/weather";
  static const String prayerAPI =
      "http://www.islamicfinder.us/index.php/api/prayer_times";
}

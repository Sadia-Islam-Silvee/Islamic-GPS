class PrayerTime {
  String fajr;
  String dhuhr;
  String asr;
  String maghrib;
  String isha;

  PrayerTime({
    required this.fajr,
    required this.dhuhr,
    required this.asr,
    required this.maghrib,
    required this.isha,
  });
}
